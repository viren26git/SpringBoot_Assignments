package com.example.product.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.dto.ProductDTO;
import com.example.product.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	
	private ProductService service;
	
	public ProductController(ProductService service)
	{
		this.service= service;
	}
	
	@PostMapping("/add")
	@ResponseStatus(HttpStatus.CREATED)
	public ProductDTO createProduct(@RequestBody ProductDTO dto) {
		System.out.println("We are into the createProduct");
		return service.createProduct(dto);
	}
	
	@GetMapping
	public List<ProductDTO> getAllProducts(){
		return service.getAllProducts();
	}
	
	@GetMapping("/{id}")
	public ProductDTO getProductById(@PathVariable Integer id) {
		return service.getProductById(id);
	}
	
	@PutMapping("/{id}")
	public ProductDTO updateProduct(@PathVariable Integer id, @RequestBody ProductDTO dto) {
		return service.updateProduct(id, dto);
	}
	
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteProduct(@PathVariable Integer id)
	{
		service.deleteProduct(id);
	}
	

}
