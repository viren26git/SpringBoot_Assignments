package com.example.product.service;

import java.util.List;

import com.example.product.dto.ProductDTO;

public interface ProductService {
	
	ProductDTO createProduct(ProductDTO dto);
	
	List<ProductDTO> getAllProducts();
	
	ProductDTO getProductById(Integer id);
	
	ProductDTO updateProduct(Integer id, ProductDTO dto);
	
	void deleteProduct(Integer id);

}
