package com.example.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.product.dto.ProductDTO;
import com.example.product.model.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	private ProductRepository repository;
	
	public ProductServiceImpl(ProductRepository repository) {
		this.repository = repository;
	}
	
	// this method used to convert from Model to DTO object
	ProductDTO convertToDTO(Product product) {
		return new ProductDTO(product.getId(),product.getName(),product.getCategory(),product.getPrice(),product.getQuantity());
	}

	@Override
	public ProductDTO createProduct(ProductDTO dto) {
		
		Product product = new Product();
		
		product.setName(dto.getName()); 
		product.setCategory(dto.getCategory()); 
		product.setPrice(dto.getPrice());
		product.setQuantity(dto.getQuantity());
		
		Product saved = repository.save(product);
		
		return convertToDTO(saved);
	}

	@Override
	public List<ProductDTO> getAllProducts() {
		
		return repository.findAll().stream().map(this::convertToDTO).toList();
	}

	@Override
	public ProductDTO getProductById(Integer id) {
		
		Product product = repository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
		return convertToDTO(product);
	}

	@Override
	public ProductDTO updateProduct(Integer id, ProductDTO dto) {
		
		Product product = repository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
		
		product.setName(dto.getName()); 
		product.setCategory(dto.getCategory()); 
		product.setPrice(dto.getPrice());
		product.setQuantity(dto.getQuantity());
		
		Product updated = repository.save(product);
		
		return convertToDTO(updated);
	}

	@Override
	public void deleteProduct(Integer id) {
		
		if(!repository.existsById(id))
		{
			throw new RuntimeException("Product not found with this id " + id);
		}
		repository.deleteById(id);
		
	}
}
