package com.example.kafka.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.kafka.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

}
