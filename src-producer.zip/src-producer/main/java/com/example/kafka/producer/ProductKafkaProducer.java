package com.example.kafka.producer;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.example.kafka.event.ProductCreatedEvent;

@Component
public class ProductKafkaProducer {
	
	private KafkaTemplate<String,ProductCreatedEvent> kafkaTemplate;

	public ProductKafkaProducer(KafkaTemplate<String,ProductCreatedEvent> kafkaTemplate) {
	  this.kafkaTemplate = kafkaTemplate;
	}
	
	public void sendProductCreatedEvent(ProductCreatedEvent event) {
		kafkaTemplate.send("product-events", event.getProductId().toString(), event);
		System.out.println(" Product event was sent to Kafka now " + event.getProductName());
	}

}
