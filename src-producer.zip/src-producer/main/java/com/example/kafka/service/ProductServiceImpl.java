package com.example.kafka.service;


import org.springframework.stereotype.Service;

import com.example.kafka.event.ProductCreatedEvent;
import com.example.kafka.model.Product;
import com.example.kafka.producer.ProductKafkaProducer;
import com.example.kafka.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	private ProductRepository productRepository;
	private ProductKafkaProducer kafkaProducer;

	public ProductServiceImpl(ProductRepository productRepository,ProductKafkaProducer kafkaProducer) {
		this.productRepository= productRepository;
		this.kafkaProducer = kafkaProducer;
	}

	@Override
	public Product createProduct(Product product) {
		
		//Step 1: saving into DB
		Product savedProduct = productRepository.save(product);
		
		//Step 2: send the product in form of event through Kafka Producer
		ProductCreatedEvent event = new ProductCreatedEvent(savedProduct.getId(),savedProduct.getName(),savedProduct.getPrice(),savedProduct.getQuantity());
		
		//Step 3: Uisng the Kafka Producer send the event to Kafka server
		kafkaProducer.sendProductCreatedEvent(event); 
		return savedProduct;
	}

}
