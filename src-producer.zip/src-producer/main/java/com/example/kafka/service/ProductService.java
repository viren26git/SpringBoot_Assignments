package com.example.kafka.service;

import com.example.kafka.model.Product;

public interface ProductService {
	
	Product createProduct(Product product);

}
