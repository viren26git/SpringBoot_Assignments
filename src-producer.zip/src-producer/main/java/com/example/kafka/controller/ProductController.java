package com.example.kafka.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.kafka.model.Product;
import com.example.kafka.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	
	private ProductService productService;

	public ProductController(ProductService productService) {
		this.productService= productService;
	}
	
	@PostMapping
	public ResponseEntity<Product> createProduct(@RequestBody Product product)
	{
		Product savedProduct = productService.createProduct(product);
		return ResponseEntity.ok(savedProduct);
	}

}
