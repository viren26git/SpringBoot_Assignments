package com.example.kafka.event;

public class ProductCreatedEvent {
	
	private Integer productId;
	private double price;
	private String productName;
	private int quantity;

	public ProductCreatedEvent() {
		
	}

	public ProductCreatedEvent(Integer productId, String productName, double price, int quantity) {
		super();
		this.productId = productId;
		this.price = price;
		this.productName = productName;
		this.quantity = quantity;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
