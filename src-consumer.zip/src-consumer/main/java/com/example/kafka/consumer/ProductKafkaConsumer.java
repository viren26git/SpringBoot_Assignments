package com.example.kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.kafka.event.ProductCreatedEvent;

@Component
public class ProductKafkaConsumer {
	
	  @KafkaListener(topics = "product-events", groupId = "inventory-group")
	  public void consumeProductCreateEvent(ProductCreatedEvent event) {
		  
		  System.out.println(" The Product event is received below....");
		  System.out.println(" Product Id " + event.getProductId());
		  System.out.println(" Product Name " + event.getProductName());
		  System.out.println(" Product price " + event.getPrice());
		  System.out.println(" Product quantity " + event.getQuantity());
		  
	  }
}
