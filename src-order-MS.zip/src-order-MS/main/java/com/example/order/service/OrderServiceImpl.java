package com.example.order.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.order.dto.OrderDTO;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;


@Service
public class OrderServiceImpl implements OrderService{
	
	private OrderRepository repository;

	public OrderServiceImpl(OrderRepository repository) {
		this.repository=repository;
	}
	
	// this method used to convert from Model to DTO object
	OrderDTO convertToDTO(Order order) {
			return new OrderDTO(order.getId(),order.getProductId(),order.getQuantity(),order.getCustomerName(),order.getTotalAmount());
		}


	@Override
	public OrderDTO createOrder(OrderDTO dto) {
		
		Order order = new Order();
		
		order.setProductId(dto.getProductId());
		order.setQuantity(dto.getQuantity());
		order.setCustomerName(dto.getCustomerName());
		order.setTotalAmount(dto.getTotalAmount());
		
		Order saved = repository.save(order);
		return convertToDTO(saved);
	}

	@Override
	public List<OrderDTO> getAllOrders() {
		
		return repository.findAll().stream().map(this::convertToDTO).toList();
	}

	@Override
	public OrderDTO getOrderById(Integer id) {
		
		Order order = repository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
		return convertToDTO(order);
	}

	@Override
	public OrderDTO updateOrder(Integer id, OrderDTO dto) {
		
		Order order = repository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
		
		order.setProductId(dto.getProductId());
		order.setQuantity(dto.getQuantity());
		order.setCustomerName(dto.getCustomerName());
		order.setTotalAmount(dto.getTotalAmount());
		
		Order updated = repository.save(order);
		return convertToDTO(updated);
	}

	@Override
	public void deleteOrder(Integer id) {
		
		if(!repository.existsById(id))
		{
			throw new RuntimeException("Order not found with this id " + id);
		}
		repository.deleteById(id);
		
	}

}
