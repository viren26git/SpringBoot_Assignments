package com.example.order.service;

import java.util.List;
import com.example.order.dto.OrderDTO;

public interface OrderService {
	
	OrderDTO createOrder(OrderDTO dto);
	
	List<OrderDTO> getAllOrders();
	
	OrderDTO getOrderById(Integer id);
	
	OrderDTO updateOrder(Integer id, OrderDTO dto);
	
	void deleteOrder(Integer id);

}
