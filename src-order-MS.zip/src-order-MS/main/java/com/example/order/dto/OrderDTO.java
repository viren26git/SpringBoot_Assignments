package com.example.order.dto;

public class OrderDTO {

	private Integer id;
	
	private Integer productId;
	
	private Integer quantity;
	
	private String customerName;
	
	private Double totalAmount;
	
	public OrderDTO() {
		
	}

	public OrderDTO(Integer id, Integer productId, Integer quantity, String customerName, Double totalAmount) {
		super();
		this.id = id;
		this.productId = productId;
		this.quantity = quantity;
		this.customerName = customerName;
		this.totalAmount = totalAmount;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

}

