package com.example.order.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OrderServiceImpl implements OrderService{
	
	private RestTemplate restTemplate;

	public OrderServiceImpl(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	@Override
	public String createOrder(Integer productId) {
		System.out.println("Creating the order .....");
		
		String inventoryURL = "http://localhost:8082/inventory/reserve/" + productId;
		
		String invetoryResponse = restTemplate.postForObject(inventoryURL, null, String.class);
		
		if(!"INVENTORY_RESERVED".equals(invetoryResponse)) {
			return " ORDER_FAILED : Inventory is not available at the moment";
		}
		
		System.out.println("Inventory got reserved !!"); 
		
		// payment service 
		
		String paymentURL = "http://localhost:8083/payment/process";
		
		String paymentResponse = restTemplate.postForObject(paymentURL, null, String.class);
		
		if(!"PAYMENT_SUCCESS".equals(paymentResponse)) {
			System.out.println("PAYMENT_FAILED : Payment failed.... starting the compensation process");
			
			String releaseURL = "http://localhost:8082/inventory/release/" + productId;
			String inventoryrelease = restTemplate.postForObject(releaseURL, null, String.class);
			
			if("INVENTORY_RELEASED".equals(inventoryrelease)) {
				return "ORDER_CANCELLED: Payment failed";
			}
		}
		
		return "ORDER_CONFIRMED";
	}

}
