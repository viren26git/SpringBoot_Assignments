package com.example.order.service;

public interface OrderService {
	
	String createOrder(Integer productId);

}
