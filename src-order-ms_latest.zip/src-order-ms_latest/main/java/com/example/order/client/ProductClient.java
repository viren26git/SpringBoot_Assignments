package com.example.order.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.order.dto.ProductDTO;

@FeignClient(name="Product-MS", fallback = ProductClientFallback.class)
public interface ProductClient {

	@GetMapping("/api/products/{id}")
	ProductDTO getProduct(@PathVariable Integer id);
	
}
