package com.example.order.client;

import org.springframework.stereotype.Component;

import com.example.order.dto.ProductDTO;

@Component
public class ProductClientFallback implements ProductClient {

	@Override
	public ProductDTO getProduct(Integer id) {
		
		ProductDTO product = new ProductDTO();
		
		product.setId(id);
		product.setName("Product Service Unavilable"); 
		product.setCategory("N/A");
		product.setPrice(0.0);
		product.setQuantity(0);
		product.setFallback(true);
		
		return product;
	}
}
