package com.example.order.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.dto.OrderDTO;
import com.example.order.dto.ProductDTO;
import com.example.order.service.OrderService;


@RestController
@RequestMapping("/api/orders")
public class OrderController {
	
	private OrderService service;

	public OrderController(OrderService service) {
		this.service = service;
	}

	@PostMapping
	public ResponseEntity<OrderDTO> createOrder(@RequestBody OrderDTO dto) {
		System.out.println("We are into the createOrder");
		return ResponseEntity.ok(service.createOrder(dto));
	}
	
	@GetMapping
	public ResponseEntity<List<OrderDTO>> getAllOrders(){
		return ResponseEntity.ok(service.getAllOrders());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<OrderDTO> getOrderById(@PathVariable Integer id) {
		return ResponseEntity.ok(service.getOrderById(id));
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<OrderDTO> updateOrder(@PathVariable Integer id, @RequestBody OrderDTO dto) {
		return ResponseEntity.ok(service.updateOrder(id, dto));
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteOrder(@PathVariable Integer id)
	{
		service.deleteOrder(id);
		return ResponseEntity.ok("Order deleted successfully !!");
	}
	
	@GetMapping("/product/{id}")
    public ResponseEntity<ProductDTO> getProduct(@PathVariable Integer id) {

        ProductDTO product = service.getProduct(id);

        return ResponseEntity.ok(product);
    }
}
