package com.example.order.dto;

public class ProductDTO {
	
	private Integer id;
	
	private String name;
	
	private Double price;
	
	private String category;
	
	private Integer quantity;
	
	private boolean fallback;
	
	public ProductDTO() {
	}

	public ProductDTO(Integer id, String name, String category, Double price, Integer quantity,boolean fallback) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.category = category;
		this.quantity = quantity;
		this.fallback = fallback;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public boolean isFallback() {
		return fallback;
	}

	public void setFallback(boolean fallback) {
		this.fallback = fallback;
	}
}


