package com.example.order.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.example.order.client.ProductClient;
import com.example.order.dto.OrderDTO;
import com.example.order.dto.ProductDTO;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;


@Service
public class OrderServiceImpl implements OrderService{
	
	private OrderRepository repository;
	private ProductClient productClient;

	public OrderServiceImpl(OrderRepository repository,ProductClient productClient) {
		this.repository=repository;
		this.productClient = productClient;
	}
	
	// this method used to convert from Model to DTO object
	OrderDTO convertToDTO(Order order) {
		
		OrderDTO dto = new OrderDTO();
		
		dto.setId(order.getId()); 
		dto.setProductId(order.getProductId()); 
		dto.setQuantity(order.getQuantity()); 
		dto.setCustomerName(order.getCustomerName());
		dto.setTotalAmount(order.getTotalAmount()); 
		
		return dto; 
		}


	@Override
	@CircuitBreaker(name="productService",fallbackMethod = "productServiceFallback")
	public OrderDTO createOrder(OrderDTO dto) {
		
		//Call Product service using  Feign
		ProductDTO product = productClient.getProduct(dto.getProductId());
		
		System.out.println(product);
		if(product == null || product.isFallback())
		{
			throw new RuntimeException("Product Service Unavailable");
		}
		
		if(product.getQuantity() < dto.getQuantity()) {
			throw new RuntimeException("Insuffcient product quantity");
		}
		
		Double totalPrice = product.getPrice() * dto.getQuantity(); // this is coming from product MS
		
		Order order = new Order();
		
		order.setProductId(dto.getProductId());
		order.setQuantity(dto.getQuantity());
		order.setCustomerName(dto.getCustomerName());
		order.setTotalAmount(totalPrice);
		
		Order saved = repository.save(order);
		return convertToDTO(saved);
	}
	
	//------------- Fallback method below ----------------//
	public OrderDTO productServiceFallback(OrderDTO dto,Throwable throwable)
	{
		OrderDTO response = new OrderDTO();
		
		response.setProductId(dto.getProductId()); 
		response.setQuantity(dto.getQuantity()); 
		response.setCustomerName("N/A");
		response.setTotalAmount(0.0); 
		
		return response;
	}

	@Override
	public List<OrderDTO> getAllOrders() {
		
		return repository.findAll().stream().map(this::convertToDTO).toList();
	}

	@Override
	public OrderDTO getOrderById(Integer id) {
		
		Order order = repository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
		return convertToDTO(order);
	}

	@Override
	@CircuitBreaker(name="productService",fallbackMethod = "updateOrderFallback")
	public OrderDTO updateOrder(Integer id, OrderDTO dto) {
		
		Order order = repository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
		
		// calling the PRODUCT-MS to fetch the product with id and caluclating the total price
		ProductDTO product = productClient.getProduct(dto.getProductId());
		if(product == null || product.isFallback())
		{
			throw new RuntimeException("Product Service Unavailable");
		}
		
		Double totalPrice = product.getPrice() * dto.getQuantity(); // this is coming from product MS
		
		order.setProductId(dto.getProductId());
		order.setQuantity(dto.getQuantity());
		order.setCustomerName(dto.getCustomerName());
		order.setTotalAmount(totalPrice);
		
		Order updated = repository.save(order);
		return convertToDTO(updated);
	}
	
	public OrderDTO updateOrderFallback(Integer id,OrderDTO dto,Throwable throwable)
	{
        OrderDTO response = new OrderDTO();
		
        response.setId(id);
		response.setProductId(dto.getProductId()); 
		response.setQuantity(dto.getQuantity()); 
		response.setTotalAmount(0.0); 
		
		return response;
	}

	@Override
	public void deleteOrder(Integer id) {
		
		if(!repository.existsById(id))
		{
			throw new RuntimeException("Order not found with this id " + id);
		}
		repository.deleteById(id);
		
	}
	
	@Override
    public ProductDTO getProduct(Integer id) {

        return productClient.getProduct(id);
    }

}
